﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



    class Program
    {
        static void Main(string[] args)
        {
           
            Person p2 = new Person();
            
            p2.Name = "Gosho";
            p2.Age = 18;
       
         }
    }

