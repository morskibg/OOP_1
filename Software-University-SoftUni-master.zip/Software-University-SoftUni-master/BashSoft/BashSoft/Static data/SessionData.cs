﻿namespace BashSoft
{
    using System.IO;

    public static class SessionData
    {
        public static string CurrentPath = Directory.GetCurrentDirectory();
    }
}
