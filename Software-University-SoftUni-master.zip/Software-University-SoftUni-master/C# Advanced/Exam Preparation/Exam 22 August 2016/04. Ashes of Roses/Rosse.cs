﻿namespace _04.Ashes_of_Roses
{
    public class Rosse
    {
        public string Color { get; set; }

        public long Amount { get; set; }
    }
}
