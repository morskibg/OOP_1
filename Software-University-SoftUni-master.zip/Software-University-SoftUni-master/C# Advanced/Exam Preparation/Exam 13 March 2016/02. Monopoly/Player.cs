﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02.Monopoly
{
    public class Player
    {
        public int Money { get; set; }

        public int Turns { get; set; }

        public int Hotels { get; set; }
    }
}
