﻿namespace _04.Jedi_Dreams
{
    using System.Collections.Generic;

    public class Method
    {
        public string Name { get; set; }

        public Queue<string> CalledMethods { get; set; }
    }
}
