﻿namespace _3.Series_Of_Numbers
{
    using System;
    using System.Linq;

    public class SeriesOfNumbers
    {
        public static void Main()
        {
            var input = Console.ReadLine();
            var result
        }
    }
}
