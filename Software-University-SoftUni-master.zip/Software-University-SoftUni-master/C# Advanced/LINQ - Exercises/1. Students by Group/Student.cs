﻿namespace _1.Students_by_Group
{
    public class Student
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public int Group { get; set; }
    }
}
