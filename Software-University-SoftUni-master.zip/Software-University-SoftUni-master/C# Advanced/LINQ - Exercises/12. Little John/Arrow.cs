﻿namespace _12.Little_John
{
    class Arrow
    {
        public string Type { get; set; }

        public int Amount { get; set; }
    }
}
