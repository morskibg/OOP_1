﻿namespace _13.Office_Stuff
{
    using System.Collections.Generic;

    class Company
    {
        public string Name { get; set; }

        public List<Product> Orders { get; set; }
    }
}
