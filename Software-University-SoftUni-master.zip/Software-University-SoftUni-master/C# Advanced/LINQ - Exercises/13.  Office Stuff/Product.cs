﻿namespace _13.Office_Stuff
{
    class Product
    {
        public string Name { get; set; }

        public int Amount { get; set; }
    }
}
