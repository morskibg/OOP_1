﻿namespace _11.Students_Joined_to_Specialties
{
    public class Student
    {
        public string Name { get; set; }

        public string Faculty { get; set; }
    }
}
