﻿namespace _11.Students_Joined_to_Specialties
{
    public class StudentSpecialty
    {
        public string Name { get; set; }

        public string Faculty { get; set; }
    }
}
