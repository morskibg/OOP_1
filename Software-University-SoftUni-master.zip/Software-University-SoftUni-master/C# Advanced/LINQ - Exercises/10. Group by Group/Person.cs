﻿namespace _10.Group_by_Group
{
    public class Person
    {
        public string Name { get; set; }

        public int Group { get; set; }
    }
}
