﻿namespace _9.Students_Enrolled_in_2014_or_2015
{
    public class Student
    {
        public string Id { get; set; }

        public int[] Marks { get; set; }
    }
}
