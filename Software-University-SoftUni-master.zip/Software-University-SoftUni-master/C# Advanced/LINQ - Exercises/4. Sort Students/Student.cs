﻿namespace _4.Sort_Students
{
    public class Student
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }
    }
}
