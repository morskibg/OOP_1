﻿namespace _2.Upper_Strings
{
    using System;

    public class UpperStrings
    {
        public static void Main()
        {
            Console.WriteLine(Console.ReadLine().ToUpper());
        }
    }
}
