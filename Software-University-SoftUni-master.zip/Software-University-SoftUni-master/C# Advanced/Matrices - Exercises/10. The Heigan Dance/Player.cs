﻿namespace _20.The_Heigan_Dance
{
    public class Player
    {
        public int[] Position { get; set; }

        public int Blood { get; set; }

        public double Damage { get; set; }

        public bool IsHitByCloud { get; set; }
    }
}