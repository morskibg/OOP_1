﻿namespace _21.vs2.Parking_System
{
    public class Car
    {
        public int EntryRow { get; set; }

        public int ParkRow { get; set; }

        public int ParkCol { get; set; }
    }
}
